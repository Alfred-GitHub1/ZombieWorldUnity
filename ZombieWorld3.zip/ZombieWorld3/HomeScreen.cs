﻿using System.Windows.Forms;

namespace ZombieWorld3 {
    public partial class HomeScreen : UserControl {
        public HomeScreen() {
            InitializeComponent();
        }

        private void HomeScreen_Load(object sender,System.EventArgs e) {

        }
    }
}
